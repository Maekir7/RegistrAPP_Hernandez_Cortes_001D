import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quienessomos',
  templateUrl: './quienessomos.page.html',
  styleUrls: ['./quienessomos.page.scss'],
})
export class QuienessomosPage implements OnInit {

  constructor() { }
  movil=false
  ngOnInit() {
    this.movil = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile|mobile|CriOS/i.test(navigator.userAgent);
  }

}
