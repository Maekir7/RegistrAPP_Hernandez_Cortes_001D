/* eslint-disable */
import { Component } from '@angular/core';

interface Componente{
  icon:string;
  name:string;
  redirecTo:string;
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor() {}


  componentes : Componente[] = [
    {
      icon: 'paw-outline',
      name: 'Entrar',
      redirecTo: '/entrar'
    },
    {
      icon: 'sunny-outline',
      name: 'Registrarse',
      redirecTo: '/registrarse'
    },
    {
      icon: 'card-outline',
      name: 'Quienes Somos',
      redirecTo: '/quienessomos'
    },   
  ];
  



}
